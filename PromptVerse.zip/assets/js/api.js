/* Public, read-only API calls use JSONP because Apps Script cannot set CORS headers. */
(function () {
  const apiUrl = window.PROMPTVERSE.apiUrl;
  function request(action, params = {}) {
    if (!apiUrl) return Promise.reject(new Error("Add the Apps Script URL in assets/js/config.js after setup."));
    return new Promise((resolve, reject) => {
      const callback = "pvCallback" + Date.now() + Math.floor(Math.random() * 10000);
      const script = document.createElement("script");
      const query = new URLSearchParams({ action, ...params, callback });
      const timer = setTimeout(() => finish(new Error("The request timed out. Please try again.")), 15000);
      function finish(error, data) {
        clearTimeout(timer); delete window[callback]; script.remove();
        error ? reject(error) : resolve(data);
      }
      window[callback] = data => data && data.ok ? finish(null, data) : finish(new Error(data?.error || "Request failed."));
      script.onerror = () => finish(new Error("Could not reach the PromptVerse API."));
      script.src = apiUrl + (apiUrl.includes("?") ? "&" : "?") + query.toString();
      document.head.appendChild(script);
    });
  }
  window.PVApi = {
    request,
    homepage: () => request("getHomepageData"),
    prompts: params => request("getPrompts", params),
    prompt: slug => request("getPromptBySlug", { slug }),
    category: slug => request("getCategoryBySlug", { slug }),
    collection: slug => request("getCollectionBySlug", { slug }),
    categories: () => request("getCategories"),
    search: params => request("searchPrompts", params),
    templates: params => request("getTemplates", params),
    trending: params => request("getTrendingPrompts", params),
    related: (slug, categoryId) => request("getRelatedPrompts", { slug, categoryId }),
    settings: () => request("getPublicSettings"),
    count: (action, slug) => request(action, { slug }),
    postForm: async (action, fields) => {
      if (!apiUrl) throw new Error("Add the Apps Script URL in assets/js/config.js after setup.");
      // Simple form POST avoids placing personal details in a public GET URL. Apps Script does not
      // expose CORS response headers, so the browser can send this but cannot read its confirmation.
      await fetch(apiUrl, {method:"POST", mode:"no-cors", headers:{"Content-Type":"application/x-www-form-urlencoded;charset=UTF-8"}, body:new URLSearchParams({action,...fields})});
      return {sent:true};
    }
  };
})();
