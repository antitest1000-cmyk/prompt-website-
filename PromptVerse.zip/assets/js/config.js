/* PromptVerse public settings. Set apiUrl after deploying Apps Script. */
window.PROMPTVERSE = {
  apiUrl: "", // Example: https://script.google.com/macros/s/DEPLOYMENT_ID/exec
  adminUrl: "", // Same Apps Script deployment URL, ending in /exec?page=admin
  siteUrl: "https://example.com",
  siteName: "PromptVerse",
  pageSize: 20
};
