function adminCall(token,action,data) {
  const admin=requireAdmin_(token);data=data||{};
  switch(String(action)) {
    case 'stats': return dashboardStats_();
    case 'list': return {ok:true,items:adminList_(String(data.table||''))};
    case 'save': return {ok:true,record:saveAdminRecord_(String(data.table||''),data.record||{})};
    case 'delete': return {ok:true,deleted:deleteAdminRecord_(String(data.table||''),String(data.id||''))};
    case 'messages': return {ok:true,items:readRows_('Messages').sort((a,b)=>String(b.created_at).localeCompare(String(a.created_at)))};
    case 'subscribers': return {ok:true,items:readRows_('Newsletter').sort((a,b)=>String(b.created_at).localeCompare(String(a.created_at)))};
    case 'exportNewsletter': return {ok:true,csv:newsletterCsv_()};
    case 'uploadMedia': return uploadMedia_(admin,data);
    case 'deleteMedia': return deleteMedia_(admin,String(data.fileId||''));
    case 'media': return {ok:true,items:listMedia_()};
    default: throw publicError_('Unknown admin operation.');
  }
}
function adminList_(table) {
  if(!Object.prototype.hasOwnProperty.call(SHEETS_,table)||['Admins','Statistics'].includes(table))throw publicError_('That record list is not available.');
  const rows=readRows_(table).sort((a,b)=>String(b.updated_at||b.created_at||'').localeCompare(String(a.updated_at||a.created_at||'')));
  return table==='Prompts'?rows.map(decoratePrompt_):rows;
}
function dashboardStats_() {
  const prompts=readRows_('Prompts'),stats=readRows_('Statistics'),today=Utilities.formatDate(new Date(),Session.getScriptTimeZone(),'yyyy-MM-dd');
  return {ok:true,stats:{totalPrompts:prompts.length,publishedPrompts:prompts.filter(x=>x.status==='published').length,draftPrompts:prompts.filter(x=>x.status!=='published').length,categories:readRows_('Categories').length,collections:readRows_('Collections').length,totalViews:prompts.reduce((n,x)=>n+(Number(x.views)||0),0),totalCopies:prompts.reduce((n,x)=>n+(Number(x.copy_count)||0),0),newsletter:readRows_('Newsletter').filter(x=>x.status==='active').length,messages:readRows_('Messages').filter(x=>x.status!=='closed').length,today:stats.find(x=>String(x.date)===today)||{total_views:0,total_copies:0}}};
}
function saveAdminRecord_(table,r) {
  if(!['Prompts','Categories','Collections','Tags','Pages','Settings'].includes(table))throw publicError_('This record type cannot be edited here.');
  const schema=SHEETS_[table],clean={};
  schema.forEach(key=>{if(r[key]===undefined||['id','created_at','updated_at'].includes(key))return;let v=r[key];if(typeof v==='string')v=v.trim();if(['is_featured','is_trending','is_pinned','is_template'].includes(key))v=bool_(v);if(['collection_ids','tags','recommended_tools','prompt_ids'].includes(key))v=parseList_(v).join('|');if(typeof v==='string'&&v.length>20000)throw publicError_('One of the fields is too long.');clean[key]=v;});
  if(table==='Settings') {if(!clean.setting_key||String(clean.setting_key).length>100)throw publicError_('Setting key is required.');const urlSettings=['site_url','site_logo','favicon','og_image','instagram_url','facebook_url','pinterest_url','youtube_url','telegram_url'];if(urlSettings.includes(String(clean.setting_key))&&clean.setting_value&&!/^https:\/\//i.test(String(clean.setting_value)))throw publicError_('Website, social and image settings must use HTTPS URLs.');const rows=readRows_('Settings'),old=(r.old_key&&rows.find(x=>x.setting_key===r.old_key))||rows.find(x=>x.setting_key===clean.setting_key);if(rows.some(x=>x.setting_key===clean.setting_key&&x.setting_key!==String(r.old_key||''))&&old&&old.setting_key!==clean.setting_key)throw publicError_('That setting key already exists.');clean.setting_value=clean.setting_value===undefined&&old?old.setting_value:clean.setting_value;return saveSetting_(clean.setting_key,clean.setting_value,r.old_key||'');}
  if(table==='Prompts') {if(!clean.title||!clean.prompt_text||!clean.category_id)throw publicError_('Prompt title, prompt text and category are required.');if(!['draft','published','archived'].includes(String(clean.status||'draft')))throw publicError_('Invalid prompt status.');if(clean.audience&&!['Boys','Girls','Couple','Unisex'].includes(String(clean.audience)))throw publicError_('Choose a supported audience.');if(clean.category_id&&!readRows_('Categories').some(x=>String(x.id)===String(clean.category_id)))throw publicError_('Choose an existing category.');if(clean.status==='published'&&!clean.published_at)clean.published_at=now_();clean.views=Math.max(0,Number(clean.views)||0);clean.copy_count=Math.max(0,Number(clean.copy_count)||0);}
  if(table==='Categories'||table==='Collections'||table==='Pages') {if(!clean.name&&!clean.title)throw publicError_('A name or title is required.');if(clean.status&&!['draft','published','active','inactive','archived'].includes(String(clean.status)))throw publicError_('Invalid status.');}
  if(table==='Tags'&&!clean.name)throw publicError_('Tag name is required.');
  ['preview_image','thumbnail_image','image','cover_image','site_logo','favicon','og_image'].forEach(key=>{if(clean[key]&& !/^https:\/\//i.test(String(clean[key])))throw publicError_('Image fields must use a public HTTPS URL.');});
  ['instagram_url','facebook_url','pinterest_url','youtube_url','telegram_url','site_url'].forEach(key=>{if(clean[key]&& !/^https:\/\//i.test(String(clean[key])))throw publicError_('Website and social links must use HTTPS URLs.');});
  const id=String(r.id||'');return writeRow_(table,clean,id||null);
}
function saveSetting_(key,value,oldKey) { const lock=LockService.getScriptLock();lock.waitLock(10000);try{const s=sheet_('Settings'),rows=readRows_('Settings'),i=rows.findIndex(x=>x.setting_key===String(oldKey||key)),stamp=now_();if(rows.some(x=>x.setting_key===key&&String(x.setting_key)!==String(oldKey||key)))throw publicError_('That setting key already exists.');if(i>=0){s.getRange(i+2,1,1,3).setValues([[sheetValue_(key),sheetValue_(value),stamp]]);}else s.appendRow([sheetValue_(key),sheetValue_(value),stamp]);return {setting_key:key,setting_value:value,updated_at:stamp};}finally{lock.releaseLock();} }
function deleteAdminRecord_(table,id) {
  if(!['Prompts','Categories','Collections','Tags','Pages','Messages','Newsletter'].includes(table))throw publicError_('This record type cannot be deleted here.');
  const rows=readRows_(table),item=rows.find(x=>String(x.id)===id);if(!item)throw publicError_('Record not found.');
  if(table==='Categories'&&readRows_('Prompts').some(p=>String(p.category_id)===id))throw publicError_('This category is still used by prompts. Move those prompts before deleting it.');
  if(table==='Collections'&&(readRows_('Prompts').some(p=>parseList_(p.collection_ids).includes(id))||readRows_('Collections').some(c=>String(c.id)===id&&parseList_(c.prompt_ids).length)))throw publicError_('Remove this collection from its prompts before deleting it.');
  if(table==='Prompts'){readRows_('Collections').forEach(c=>{const ids=parseList_(c.prompt_ids);if(ids.includes(id))writeRow_('Collections',{prompt_ids:ids.filter(x=>x!==id).join('|')},String(c.id));});}
  return deleteRow_(table,id);
}
function newsletterCsv_() { const rows=readRows_('Newsletter'),csv=[['email','status','created_at'],...rows.map(r=>[r.email,r.status,r.created_at])];return csv.map(r=>r.map(x=>'"'+String(x||'').replace(/"/g,'""')+'"').join(',')).join('\r\n'); }
