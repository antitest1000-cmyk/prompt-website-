function createInitialAdmin(setupToken,email,name,password) {
  const lock=LockService.getScriptLock();lock.waitLock(30000);try{
    if(PropertiesService.getScriptProperties().getProperty('SETUP_COMPLETE')!=='true') throw new Error('Run initializePromptVerse_ first.');
    if(readRows_('Admins').some(a=>a.status==='active')) throw new Error('An active admin already exists.');
    const props=PropertiesService.getScriptProperties(),expected=props.getProperty('INITIAL_ADMIN_SETUP_TOKEN');if(!expected||!constantTimeEqual_(setupToken,expected))throw publicError_('The one-time setup token is invalid or has already been used.');
    email=String(email||'').trim().toLowerCase();if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||String(password||'').length<12)throw publicError_('Use a valid email and a password with at least 12 characters.');
    const salt=Utilities.getUuid()+Utilities.getUuid(),hash=passwordHash_(password,salt),row={id:id_(),name:String(name||'Administrator').slice(0,100),email,password_hash:salt+':'+hash,status:'active',last_login:'',created_at:now_()};
    sheet_('Admins').appendRow(SHEETS_.Admins.map(k=>row[k]||''));props.deleteProperty('INITIAL_ADMIN_SETUP_TOKEN');
    return 'Administrator created. Save the password in a password manager.';
  } finally { lock.releaseLock(); }
}
function passwordHash_(password,salt) {
  // PBKDF2-HMAC-SHA256, 100,000 rounds; salt is unique per administrator.
  const key=Utilities.newBlob(String(password)).getBytes(), msg=Utilities.newBlob(String(salt)+'\u0000'+'\u0000\u0000\u0001').getBytes();
  let u=Utilities.computeHmacSha256Signature(msg,key), out=u.slice();
  for(let i=1;i<100000;i++){u=Utilities.computeHmacSha256Signature(u,key);for(let j=0;j<out.length;j++)out[j]^=u[j];}
  return Utilities.base64Encode(out);
}
function constantTimeEqual_(a,b) { a=String(a);b=String(b);let diff=a.length^b.length,n=Math.max(a.length,b.length);for(let i=0;i<n;i++)diff|=(a.charCodeAt(i)||0)^(b.charCodeAt(i)||0);return diff===0; }
function adminLogin(email,password) {
  email=String(email||'').trim().toLowerCase();const cache=CacheService.getScriptCache(),key='login:'+Utilities.base64EncodeWebSafe(email).slice(0,60),attempts=Number(cache.get(key)||0);
  if(attempts>=6) throw publicError_('Too many login attempts. Wait 15 minutes and try again.');
  const admin=readRows_('Admins').find(a=>String(a.email).toLowerCase()===email&&a.status==='active');
  let valid=false;if(admin&&admin.password_hash){const parts=String(admin.password_hash).split(':');valid=parts.length===2&&constantTimeEqual_(passwordHash_(String(password||''),parts[0]),parts[1]);}
  if(!valid){cache.put(key,String(attempts+1),900);throw publicError_('Email or password is incorrect.');}
  cache.remove(key);const token=Utilities.getUuid()+Utilities.getUuid(),session={id:String(admin.id),email:admin.email,name:admin.name,expires:Date.now()+21600000};cache.put('session:'+token,JSON.stringify(session),21600);
  writeRow_('Admins',{last_login:now_()},String(admin.id));return {ok:true,token,name:admin.name,expires:session.expires};
}
function adminLogout(token) { if(token)CacheService.getScriptCache().remove('session:'+String(token));return {ok:true}; }
function requireAdmin_(token) { const raw=CacheService.getScriptCache().get('session:'+String(token||''));if(!raw)throw publicError_('Your admin session expired. Please log in again.');const a=JSON.parse(raw),admin=readRows_('Admins').find(x=>String(x.id)===a.id&&x.status==='active');if(!admin)throw publicError_('Admin access is no longer active.');return admin; }
function changeAdminPassword(token,currentPassword,newPassword) { const admin=requireAdmin_(token),parts=String(admin.password_hash||'').split(':');if(parts.length!==2||!constantTimeEqual_(passwordHash_(String(currentPassword||''),parts[0]),parts[1]))throw publicError_('Current password is incorrect.');if(String(newPassword||'').length<12)throw publicError_('New password must have at least 12 characters.');const salt=Utilities.getUuid()+Utilities.getUuid();writeRow_('Admins',{password_hash:salt+':'+passwordHash_(newPassword,salt)},String(admin.id));return {ok:true}; }
