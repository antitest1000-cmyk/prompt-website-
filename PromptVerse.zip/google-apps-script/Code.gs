/* PromptVerse Apps Script entry points. Create a bound script from the target spreadsheet. */
function doGet(e) {
  const p = (e && e.parameter) || {};
  if (p.page === 'admin') return HtmlService.createHtmlOutputFromFile('Admin').setTitle('PromptVerse Admin');
  if (!p.action) return ContentService.createTextOutput('PromptVerse API is running. Use ?action=getHomepageData&callback=yourCallback').setMimeType(ContentService.MimeType.TEXT);
  let response;
  try { if(['subscribeNewsletter','submitContactMessage'].includes(String(p.action))) throw publicError_('Send form submissions with POST.'); response = publicAction_(String(p.action), p); }
  catch (err) { response = { ok: false, error: safeError_(err) }; }
  const json = JSON.stringify(response);
  if (p.callback && /^[A-Za-z_$][\w.$]{0,80}$/.test(p.callback)) return ContentService.createTextOutput(p.callback + '(' + json + ');').setMimeType(ContentService.MimeType.JAVASCRIPT);
  return ContentService.createTextOutput(json).setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  // Optional form-compatible endpoint; browser admin writes use google.script.run instead.
  let body = {};
  try { body = JSON.parse((e.postData && e.postData.contents) || '{}'); } catch (err) { body = e.parameter || {}; }
  try { return ContentService.createTextOutput(JSON.stringify(publicAction_(String(body.action || ''), body))).setMimeType(ContentService.MimeType.JSON); }
  catch (err) { return ContentService.createTextOutput(JSON.stringify({ ok: false, error: safeError_(err) })).setMimeType(ContentService.MimeType.JSON); }
}

function include_(filename) { return HtmlService.createHtmlOutputFromFile(filename).getContent(); }
function safeError_(err) { console.error(err && err.stack || err); return err && err.publicMessage ? err.publicMessage : 'The request could not be completed.'; }
