const SHEETS_ = {
  Prompts: ['id','title','slug','short_description','prompt_text','prompt_text_hi','preview_image','thumbnail_image','image_alt','category_id','collection_ids','tags','audience','prompt_type','recommended_tools','how_to_use','tips','suitable_for','additional_content','is_featured','is_trending','is_pinned','is_template','status','views','copy_count','seo_title','seo_description','published_at','created_at','updated_at'],
  Categories: ['id','name','slug','description','image','meta_title','meta_description','sort_order','status','created_at','updated_at'],
  Collections: ['id','name','slug','description','cover_image','prompt_ids','meta_title','meta_description','is_featured','status','created_at','updated_at'],
  Tags: ['id','name','slug','created_at'],
  Pages: ['id','title','slug','content','seo_title','seo_description','status','created_at','updated_at'],
  Settings: ['setting_key','setting_value','updated_at'],
  Admins: ['id','name','email','password_hash','status','last_login','created_at'],
  Newsletter: ['id','email','status','created_at'],
  Messages: ['id','name','email','subject','message','status','created_at'],
  Statistics: ['date','total_views','total_copies','total_visitors']
};

function spreadsheet_() {
  const id = PropertiesService.getScriptProperties().getProperty('SPREADSHEET_ID');
  if (!id) throw new Error('Setup is incomplete. Bind this script to a spreadsheet, then run initializePromptVerse_.');
  return SpreadsheetApp.openById(id);
}
function sheet_(name) { const s = spreadsheet_().getSheetByName(name); if (!s) throw new Error('Database sheet missing: ' + name); return s; }
function readRows_(name) {
  const s = sheet_(name), values = s.getDataRange().getValues();
  if (values.length < 2) return [];
  const headers = values[0].map(String);
  return values.slice(1).filter(row => row.some(v => v !== '')).map(row => { const item = {}; headers.forEach((h,i) => item[h] = row[i]); return item; });
}
function now_() { return new Date().toISOString(); }
function id_() { return Utilities.getUuid(); }
function parseList_(value) { return Array.isArray(value) ? value : String(value || '').split(/[|,]/).map(s => s.trim()).filter(Boolean); }
function bool_(value) { return value === true || String(value).toLowerCase() === 'true' || String(value) === '1'; }
function writeRow_(sheetName, input, existingId) {
  const lock = LockService.getScriptLock(); lock.waitLock(10000);
  try {
    const s=sheet_(sheetName), headers=SHEETS_[sheetName], rows=readRows_(sheetName), old=existingId ? rows.find(r=>String(r.id)===String(existingId)) : null;
    const record=Object.assign({}, old || {}, input);
    if (headers.includes('id')) record.id = old ? old.id : (record.id || id_());
    const stamp=now_(); if (headers.includes('created_at') && !record.created_at) record.created_at=stamp; if (headers.includes('updated_at')) record.updated_at=stamp;
    if (headers.includes('slug')) {
      record.slug = slugify_(record.slug || record.title || record.name || 'item');
      if (rows.some(r=>String(r.slug)===record.slug && String(r.id)!==String(record.id))) throw publicError_('That URL slug is already in use.');
    }
    const line=headers.map(h=>sheetValue_(record[h] === undefined ? '' : (Array.isArray(record[h]) ? record[h].join('|') : record[h])));
    if (old) { const row=rows.findIndex(r=>String(r.id)===String(old.id))+2; s.getRange(row,1,1,headers.length).setValues([line]); }
    else s.appendRow(line);
    return record;
  } finally { lock.releaseLock(); }
}
function deleteRow_(sheetName, id) { const lock=LockService.getScriptLock();lock.waitLock(10000);try{const s=sheet_(sheetName),rows=readRows_(sheetName),index=rows.findIndex(r=>String(r.id)===String(id));if(index<0)return false;s.deleteRow(index+2);return true;}finally{lock.releaseLock();} }
function slugify_(value) { return String(value||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,100) || 'item'; }
function sheetValue_(value) { return typeof value==='string'&&/^[=+\-@]/.test(value)?"'"+value:value; }
function publicError_(message) { const e=new Error(message); e.publicMessage=message; return e; }

function initializePromptVerse_() {
  const ss=SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) throw new Error('Open Apps Script from Extensions → Apps Script in the target spreadsheet.');
  if(PropertiesService.getScriptProperties().getProperty('SETUP_COMPLETE')==='true') throw new Error('Setup is already complete. This initializer clears database tabs; it is disabled to prevent accidental data loss.');
  PropertiesService.getScriptProperties().setProperty('SPREADSHEET_ID',ss.getId());
  Object.keys(SHEETS_).forEach(name=>{ let s=ss.getSheetByName(name); if(!s)s=ss.insertSheet(name); s.clearContents(); s.getRange(1,1,1,SHEETS_[name].length).setValues([SHEETS_[name]]); s.setFrozenRows(1); s.getRange(1,1,1,SHEETS_[name].length).setFontWeight('bold'); });
  seedDemoData_();
  const props=PropertiesService.getScriptProperties();
  if(!props.getProperty('MEDIA_FOLDER_ID')) { const folder=DriveApp.createFolder('PromptVerse Media'); props.setProperty('MEDIA_FOLDER_ID',folder.getId()); }
  const bootstrap=Utilities.getUuid()+Utilities.getUuid();props.setProperty('INITIAL_ADMIN_SETUP_TOKEN',bootstrap);props.setProperty('SETUP_COMPLETE','true');
  Logger.log('One-time first-admin setup token (copy it now; it is not shown again): '+bootstrap);
  return 'Database initialized. Open Executions → this run → Logs and copy the one-time setup token. Use it once in the Admin page to create your password.';
}

function buildSitemapXml_() {
  const base=String((readRows_('Settings').find(x=>x.setting_key==='site_url')||{}).setting_value||'https://example.com').replace(/\/$/,'');
  const urls=[base+'/',base+'/prompts/',base+'/category/',base+'/collection/',base+'/templates/'];
  publishedPrompts_().forEach(p=>urls.push(base+'/prompt/'+encodeURIComponent(String(p.slug))+'/'));
  categoriesWithCounts_().forEach(c=>urls.push(base+'/category/'+encodeURIComponent(String(c.slug))+'/'));
  collectionsWithCounts_().forEach(c=>urls.push(base+'/collection/'+encodeURIComponent(String(c.slug))+'/'));
  readRows_('Pages').filter(p=>p.status==='published').forEach(p=>urls.push(base+'/'+encodeURIComponent(String(p.slug))+'/'));
  const unique=Array.from(new Set(urls));const xml='<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'+unique.map(u=>'  <url><loc>'+escapeXml_(u)+'</loc></url>').join('\n')+'\n</urlset>';
  Logger.log(xml);return xml;
}
function escapeXml_(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;'); }
function seedDemoData_() {
  const stamp=now_();
  const cats=[['portrait','Portraits','Expressive portrait ideas'],['cinematic','Cinematic scenes','Mood-rich visual storytelling'],['fashion','Fashion','Editorial styling and fashion concepts'],['couple','Couple photos','Warm shared moments'],['illustration','Illustration & anime','Playful drawn worlds']];
  const catIds={}; cats.forEach((c,i)=>{const r=writeRow_('Categories',{id:'cat-'+(i+1),name:c[1],slug:c[0],description:c[2],image:'',meta_title:c[1]+' AI prompts | PromptVerse',meta_description:c[2],sort_order:i+1,status:'published',created_at:stamp},null);catIds[c[0]]=r.id;});
  const collections=[['soft-light-portraits','Soft light portraits','Gentle light and intimate expression'],['little-cinema','Little cinema','Story-rich cinematic directions'],['creative-starters','Creative starters','Flexible prompts to make your own']];
  const colIds={};collections.forEach((c,i)=>{const r=writeRow_('Collections',{id:'col-'+(i+1),name:c[1],slug:c[0],description:c[2],cover_image:'',prompt_ids:'',is_featured:true,status:'published',created_at:stamp},null);colIds[c[0]]=r.id;});
  const samples=[
    ['Windowlight study','portrait','Unisex','A quiet portrait shaped by a soft beam of morning light.','portrait','soft-light-portraits'],
    ['After the last train','cinematic','Unisex','A cinematic station scene with a small human story at its center.','cinematic','little-cinema'],
    ['Color in motion','fashion','Girls','An editorial fashion frame full of movement and bold color.','fashion','creative-starters'],
    ['Sunday, somewhere sunny','couple','Couple','A candid couple portrait with natural warmth and film texture.','portrait','soft-light-portraits'],
    ['Paper moon garden','illustration','Unisex','A whimsical hand-drawn garden under an oversized paper moon.','illustration','creative-starters'],
    ['Blue hour portrait','portrait','Boys','A thoughtful portrait in the cool glow just after sunset.','portrait','soft-light-portraits'],
    ['The velvet runway','fashion','Girls','A dramatic runway look against a sculptural deep-plum set.','fashion','creative-starters'],
    ['Rain on the arcade','cinematic','Unisex','Neon reflections turn a rainy arcade into a cinematic dream.','cinematic','little-cinema'],
    ['Two cups, one morning','couple','Couple','An intimate lifestyle photo of a slow shared morning.','portrait','soft-light-portraits'],
    ['Tiny astronaut, big sky','illustration','Unisex','A charming anime-inspired explorer in a field of stars.','illustration','creative-starters']
  ];
  samples.forEach((s,i)=>{const slug=slugify_(s[0]);writeRow_('Prompts',{id:'sample-'+(i+1),title:s[0],slug,short_description:s[3],prompt_text:'Create an original '+s[0].toLowerCase()+': '+s[3]+' Use an intentional composition, tactile detail, natural visual coherence, and a distinctive but believable color palette. Avoid text, logos, watermarks, extra fingers, and distorted anatomy.',prompt_text_hi:'',preview_image:'',thumbnail_image:'',image_alt:s[0]+' AI prompt preview',category_id:catIds[s[1]],collection_ids:colIds[s[5]],tags:s[2].toLowerCase()+'|creative|original',audience:s[2],prompt_type:s[4],recommended_tools:'Image generation|Photo editing',how_to_use:'Copy the prompt and adapt the subject, setting, and color palette to fit your idea.',tips:'Add a specific camera angle or lighting reference to make the result more personal.',suitable_for:'Personal creative projects and mood boards',additional_content:'Use this as a starting point. Adjust details to match your own creative direction.',is_featured:i<4,is_trending:i<4,is_pinned:i===0,is_template:i===9,status:'published',views:0,copy_count:0,seo_title:s[0]+' AI prompt | PromptVerse',seo_description:s[3],published_at:stamp,created_at:stamp,updated_at:stamp},null);});
  const pages=[['About Us','about','PromptVerse is an independent prompt discovery gallery built to help creators find a useful spark. Our original demonstration content is here to show how this site can be organized.'],['Privacy Policy','privacy-policy','We collect only the information you submit through our newsletter and contact forms. The site operator should update this policy to describe its actual hosting, analytics, advertising and retention practices before launch.'],['Terms and Conditions','terms-and-conditions','Use prompts as creative starting points and review the terms of the AI tools you choose. The site operator should obtain appropriate legal advice and customize these terms before launch.'],['Disclaimer','disclaimer','Prompt outputs vary by tool, model, settings and user edits. PromptVerse does not guarantee a particular output or endorse any third-party AI service. Customize this disclaimer for your actual business before launch.'],['DMCA / Copyright Policy','dmca','To report content you believe infringes copyright, contact the site operator with the work identified, the page URL and your contact details. The operator should add a valid designated agent and jurisdiction-specific process before launch.']];
  pages.forEach(p=>writeRow_('Pages',{title:p[0],slug:p[1],content:p[2],seo_title:p[0]+' | PromptVerse',seo_description:p[2].slice(0,155),status:'published',created_at:stamp,updated_at:stamp},null));
  [['site_name','PromptVerse'],['site_tagline','Thoughtful prompts for your next creative idea'],['site_url','https://example.com'],['site_description','An original discovery gallery for creative AI prompts.'],['site_logo',''],['favicon',''],['contact_email','hello@example.com'],['footer_copyright','© PromptVerse'],['instagram_url',''],['facebook_url',''],['pinterest_url',''],['youtube_url',''],['telegram_url',''],['default_seo_title','PromptVerse — Creative AI prompts'],['default_meta_description','Discover original AI prompts for images, video and creative editing.'],['homepage_seo_content','PromptVerse is a growing gallery of original prompts for AI image generation, editing, portrait photography, fashion concepts, cinematic scenes, video, illustration and more. Browse by category, explore curated collections, or search for a creative idea.'],['og_image',''],['google_analytics_id',''],['search_console_verification',''],['prompts_per_page','20'],['newsletter_enabled','true'],['ads_enabled','false'],['featured_collections_enabled','true'],['social_sharing_enabled','true'],['ad_header',''],['ad_home_after_hero',''],['ad_home_gallery',''],['ad_category',''],['ad_prompt_detail',''],['ad_sidebar',''],['ad_footer','']].forEach(s=>writeRow_('Settings',{setting_key:s[0],setting_value:s[1],updated_at:stamp},null));
}
