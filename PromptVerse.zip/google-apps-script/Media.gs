function uploadMedia_(admin,data) {
  const filename=String(data.filename||'upload'),mime=String(data.mimeType||''),base64=String(data.base64||'');
  const allowed={'image/jpeg':['jpg','jpeg'],'image/png':['png'],'image/webp':['webp'],'image/gif':['gif']};
  const ext=(filename.split('.').pop()||'').toLowerCase();if(!allowed[mime]||!allowed[mime].includes(ext))throw publicError_('Use a JPG, PNG, WEBP or GIF image.');
  if(base64.length>4*1024*1024)throw publicError_('Image is too large. Maximum size is 3 MB.');
  const bytes=Utilities.base64Decode(base64),blob=Utilities.newBlob(bytes,mime,Utilities.getUuid()+'.'+ext);if(blob.getBytes().length>3*1024*1024)throw publicError_('Image is too large. Maximum size is 3 MB.');
  if(!imageSignatureMatches_(bytes,mime))throw publicError_('The file contents do not match an allowed image format.');
  const folderId=PropertiesService.getScriptProperties().getProperty('MEDIA_FOLDER_ID');if(!folderId)throw publicError_('Media folder is not configured. Run setup first.');
  const file=DriveApp.getFolderById(folderId).createFile(blob);file.setSharing(DriveApp.Access.ANYONE_WITH_LINK,DriveApp.Permission.VIEW);
  return {ok:true,file:{id:file.getId(),name:file.getName(),url:'https://drive.google.com/uc?export=view&id='+file.getId(),thumbnail:'https://drive.google.com/thumbnail?id='+file.getId()+'&sz=w1200'}};
}
function imageSignatureMatches_(b,mime) { const byte=i=>b[i]&255;if(mime==='image/jpeg')return b.length>3&&byte(0)===255&&byte(1)===216&&byte(2)===255;if(mime==='image/png')return b.length>8&&[137,80,78,71,13,10,26,10].every((v,i)=>byte(i)===v);if(mime==='image/gif'){const sig=String.fromCharCode(...b.slice(0,6));return b.length>6&&(sig==='GIF89a'||sig==='GIF87a');}if(mime==='image/webp')return b.length>12&&String.fromCharCode(...b.slice(0,4))==='RIFF'&&String.fromCharCode(...b.slice(8,12))==='WEBP';return false; }
function deleteMedia_(admin,fileId) {
  const file=DriveApp.getFileById(fileId),url='id='+fileId;
  const parents=file.getParents(),folderId=PropertiesService.getScriptProperties().getProperty('MEDIA_FOLDER_ID');let belongs=false;while(parents.hasNext())if(parents.next().getId()===folderId)belongs=true;if(!belongs)throw publicError_('This file is outside the PromptVerse media folder.');
  const referenced=['Prompts','Categories','Collections','Settings'].some(t=>readRows_(t).some(r=>Object.keys(r).some(k=>String(r[k]||'').includes(url))));
  if(referenced)throw publicError_('This image is still referenced in the site data. Remove those references first.');file.setTrashed(true);return {ok:true};
}
function listMedia_() { const folderId=PropertiesService.getScriptProperties().getProperty('MEDIA_FOLDER_ID');if(!folderId)return [];const files=DriveApp.getFolderById(folderId).getFiles(),out=[];while(files.hasNext()){const f=files.next();out.push({id:f.getId(),name:f.getName(),url:'https://drive.google.com/uc?export=view&id='+f.getId(),thumbnail:'https://drive.google.com/thumbnail?id='+f.getId()+'&sz=w400',created_at:f.getDateCreated().toISOString()});}return out.sort((a,b)=>b.created_at.localeCompare(a.created_at)); }
