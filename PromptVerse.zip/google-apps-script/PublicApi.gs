function publicAction_(action, p) {
  switch(action) {
    case 'getHomepageData': return homepageData_();
    case 'getPrompts': return promptList_(p);
    case 'getTemplates': return promptList_(Object.assign({},p,{template:'true'}));
    case 'searchPrompts': return promptList_(p);
    case 'getTrendingPrompts': return promptList_(Object.assign({},p,{trending:'true',sort:'popular'}));
    case 'getPromptBySlug': return promptBySlug_(p.slug);
    case 'getCategoryBySlug': return categoryBySlug_(p.slug);
    case 'getCollectionBySlug': return collectionBySlug_(p.slug);
    case 'getCategories': return {ok:true,items:categoriesWithCounts_()};
    case 'getCollections': return {ok:true,items:collectionsWithCounts_()};
    case 'getFeaturedCollections': return {ok:true,items:collectionsWithCounts_().filter(c=>bool_(c.is_featured))};
    case 'getRelatedPrompts': return relatedPrompts_(p);
    case 'getPublicSettings': return publicSettings_();
    case 'getPageBySlug': return pageBySlug_(p.slug);
    case 'incrementViewCount': return incrementCounter_(p.slug,'views');
    case 'incrementCopyCount': return incrementCounter_(p.slug,'copy_count');
    case 'subscribeNewsletter': return subscribe_(p);
    case 'submitContactMessage': return contact_(p);
    default: throw publicError_('Unknown API operation.');
  }
}
function publishedPrompts_() { return readRows_('Prompts').filter(p=>String(p.status)==='published'); }
function decoratePrompt_(p) {
  const cat=readRows_('Categories').find(c=>String(c.id)===String(p.category_id));
  return Object.assign({},p,{category_name:cat?cat.name:'',category_slug:cat?cat.slug:'',tags:parseList_(p.tags),collection_ids:parseList_(p.collection_ids),recommended_tools:parseList_(p.recommended_tools),is_featured:bool_(p.is_featured),is_trending:bool_(p.is_trending),is_pinned:bool_(p.is_pinned),is_template:bool_(p.is_template)});
}
function promptList_(p) {
  let rows=publishedPrompts_();
  const category=String(p.category||'').toLowerCase(), collection=String(p.collection||'').toLowerCase(), q=String(p.q||'').trim().toLowerCase(), audience=String(p.audience||'').toLowerCase(), type=String(p.promptType||p.type||'').toLowerCase();
  if(category) { const c=readRows_('Categories').find(x=>x.slug===category && x.status==='published'); rows=c?rows.filter(x=>String(x.category_id)===String(c.id)):[]; }
  if(collection) { const c=readRows_('Collections').find(x=>x.slug===collection && x.status==='published'); rows=c?rows.filter(x=>parseList_(x.collection_ids).includes(String(c.id)) || parseList_(c.prompt_ids).includes(String(x.id))):[]; }
  if(String(p.trending)==='true') rows=rows.filter(x=>bool_(x.is_trending));
  if(String(p.template)==='true') rows=rows.filter(x=>bool_(x.is_template));
  if(audience) rows=rows.filter(x=>String(x.audience||'').toLowerCase()===audience);
  if(type) rows=rows.filter(x=>String(x.prompt_type||'').toLowerCase()===type);
  if(q) rows=rows.filter(x=>[x.title,x.short_description,x.prompt_text,x.tags,x.prompt_type].some(v=>String(v||'').toLowerCase().includes(q)) || (readRows_('Categories').find(c=>String(c.id)===String(x.category_id))||{}).name?.toLowerCase().includes(q));
  const sort=String(p.sort||'latest');
  rows.sort((a,b)=>sort==='popular'?Number(b.views||0)-Number(a.views||0):sort==='copied'?Number(b.copy_count||0)-Number(a.copy_count||0):String(b.published_at||'').localeCompare(String(a.published_at||'')));
  const total=rows.length, limit=Math.min(50,Math.max(1,Number(p.limit)||20)), pages=Math.max(1,Math.ceil(total/limit)), page=Math.min(pages,Math.max(1,Number(p.page)||1));
  return {ok:true,items:rows.slice((page-1)*limit,page*limit).map(decoratePrompt_),total,page,totalPages:pages,limit};
}
function isPublished_(item) { return item.status==='published'||item.status==='active'; }
function categoriesWithCounts_() { const prompts=publishedPrompts_(); return readRows_('Categories').filter(isPublished_).sort((a,b)=>Number(a.sort_order||0)-Number(b.sort_order||0)).map(c=>Object.assign({},c,{prompt_count:prompts.filter(p=>String(p.category_id)===String(c.id)).length})); }
function collectionsWithCounts_() { const prompts=publishedPrompts_(); return readRows_('Collections').filter(isPublished_).map(c=>Object.assign({},c,{prompt_count:prompts.filter(p=>parseList_(p.collection_ids).includes(String(c.id))||parseList_(c.prompt_ids).includes(String(p.id))).length})); }
function homepageData_() { return {ok:true,categories:categoriesWithCounts_(),collections:collectionsWithCounts_().filter(c=>bool_(c.is_featured)).slice(0,6),trending:publishedPrompts_().filter(p=>bool_(p.is_trending)).sort((a,b)=>Number(b.views||0)-Number(a.views||0)).slice(0,8).map(decoratePrompt_),latest:publishedPrompts_().sort((a,b)=>String(b.published_at||'').localeCompare(String(a.published_at||''))).slice(0,8).map(decoratePrompt_)}; }
function promptBySlug_(slug) { const p=publishedPrompts_().find(x=>x.slug===String(slug||'')); if(!p) throw publicError_('Prompt not found.'); return {ok:true,prompt:decoratePrompt_(p)}; }
function categoryBySlug_(slug) { const c=categoriesWithCounts_().find(x=>x.slug===String(slug||'')); if(!c) throw publicError_('Category not found.'); return {ok:true,category:c}; }
function collectionBySlug_(slug) { const c=collectionsWithCounts_().find(x=>x.slug===String(slug||'')); if(!c) throw publicError_('Collection not found.'); return {ok:true,collection:c}; }
function relatedPrompts_(p) { const all=publishedPrompts_(), current=all.find(x=>x.slug===String(p.slug||'')); const categoryId=p.categoryId||p.category_id||(current&&current.category_id); return {ok:true,items:all.filter(x=>x.slug!==String(p.slug||'')&&(!categoryId||String(x.category_id)===String(categoryId))).slice(0,4).map(decoratePrompt_)}; }
function pageBySlug_(slug) { const p=readRows_('Pages').find(x=>x.slug===String(slug||'')&&x.status==='published'); if(!p) throw publicError_('Page not found.'); return {ok:true,page:Object.assign({},p,{content_html:plainTextHtml_(p.content)})}; }
function plainTextHtml_(text) { return String(text||'').split(/\n\s*\n/).map(s=>'<p>'+escapeHtml_(s).replace(/\n/g,'<br>')+'</p>').join(''); }
function escapeHtml_(s) { return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function publicSettings_() { const allowed=['site_name','site_tagline','site_url','site_description','site_logo','favicon','contact_email','footer_copyright','instagram_url','facebook_url','pinterest_url','youtube_url','telegram_url','default_seo_title','default_meta_description','homepage_seo_content','og_image','google_analytics_id','search_console_verification','prompts_per_page','newsletter_enabled','ads_enabled','featured_collections_enabled','social_sharing_enabled'];const rows=readRows_('Settings'),settings={};rows.forEach(s=>{if(allowed.includes(String(s.setting_key)))settings[s.setting_key]=s.setting_value;});if(String(settings.ads_enabled)==='true')rows.forEach(s=>{if(String(s.setting_key).startsWith('ad_'))settings[s.setting_key]=s.setting_value;});return {ok:true,settings}; }
function incrementCounter_(slug,field) {
  const lock=LockService.getScriptLock();lock.waitLock(10000);try{const s=sheet_('Prompts'),rows=readRows_('Prompts'),i=rows.findIndex(p=>p.slug===String(slug||'')&&p.status==='published');if(i<0)return {ok:false,error:'Prompt not found.'};const row=i+2,headers=SHEETS_.Prompts,col=headers.indexOf(field)+1,old=Number(s.getRange(row,col).getValue())||0;s.getRange(row,col).setValue(old+1);dailyStat_(field==='views'?'total_views':'total_copies');return {ok:true,count:old+1};}finally{lock.releaseLock();}
}
function dailyStat_(field) { const date=Utilities.formatDate(new Date(),Session.getScriptTimeZone(),'yyyy-MM-dd'),s=sheet_('Statistics'),rows=readRows_('Statistics'),i=rows.findIndex(r=>String(r.date)===date);if(i<0){const row={date,total_views:0,total_copies:0,total_visitors:0};row[field]=1;s.appendRow(SHEETS_.Statistics.map(k=>row[k]||0));}else{const col=SHEETS_.Statistics.indexOf(field)+1;s.getRange(i+2,col).setValue((Number(rows[i][field])||0)+1);}}
function subscribe_(p) { const setting=readRows_('Settings').find(x=>x.setting_key==='newsletter_enabled');if(setting&&String(setting.setting_value)==='false')throw publicError_('Newsletter subscriptions are currently closed.');const email=String(p.email||'').trim().toLowerCase();if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||email.length>200)throw publicError_('Enter a valid email address.');const lock=LockService.getScriptLock();lock.waitLock(10000);try{const s=sheet_('Newsletter'),rows=readRows_('Newsletter');if(rows.some(r=>String(r.email).toLowerCase()===email))return {ok:true,message:'This email is already subscribed.'};const row={id:id_(),email,status:'active',created_at:now_()};s.appendRow(SHEETS_.Newsletter.map(k=>row[k]||''));return {ok:true,message:'Subscription saved.'};}finally{lock.releaseLock();} }
function contact_(p) { if(String(p.website||'').trim()) return {ok:true,message:'Thanks. Your message has been received.'};const name=String(p.name||'').trim(),email=String(p.email||'').trim().toLowerCase(),subject=String(p.subject||'').trim(),message=String(p.message||'').trim();if(!name||name.length>100||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||email.length>200||!subject||subject.length>160||!message||message.length>5000)throw publicError_('Please check the form fields and try again.');const key='contact:'+Utilities.base64EncodeWebSafe(email).slice(0,60),cache=CacheService.getScriptCache(),count=Number(cache.get(key)||0);if(count>=3)throw publicError_('Please wait before sending another message.');cache.put(key,String(count+1),3600);writeRow_('Messages',{name,email,subject,message,status:'new',created_at:now_()},null);return {ok:true,message:'Thanks. Your message has been received.'}; }
