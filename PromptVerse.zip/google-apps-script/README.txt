APPS SCRIPT FILE IMPORT
=======================
Create a bound Apps Script project from the dedicated PromptVerse spreadsheet. Add the six .gs files as separate script files and Admin.html as an HTML file named “Admin”. Apps Script combines the .gs files into one project; function order is not important.

Run initializePromptVerse_ once. It uses the active bound spreadsheet, creates the sheets and media folder, and seeds the demo data. It is intentionally guarded after its first successful run because its first-run behavior clears the expected tabs. The setup token appears in the Apps Script execution log. The first admin is created through the one-time form on the deployed Admin page, not by storing a plaintext password in a sheet.

Deploy as a Web App that executes as the spreadsheet owner. Public access is necessary for public GET reads. The spreadsheet remains private; public API handlers expose only published rows. Admin HTML is also reachable at ?page=admin, but every admin data call requires an expiring server-side session.

The code uses JSONP for public reads and simple form POST for newsletter/contact writes. Apps Script cannot be configured here to return arbitrary Access-Control-Allow-Origin headers. Admin CRUD stays within HtmlService and google.script.run. The no-cors public forms cannot read a success body; inspect the sheet to confirm the first live submissions.

buildSitemapXml_ logs a fresh XML sitemap for the configured site_url. Copy that output to the static host's sitemap.xml after each batch of content changes. It does not upload to your hosting provider.
